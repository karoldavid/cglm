
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'zyskkd',
  applicationName: 'attendance-app',
  appUid: 'zzw25P87wz6GN3t309',
  orgUid: 'bjrHrbt9Twy1n7m82R',
  deploymentUid: '3d99e327-3cc5-42ff-9204-cc8dc783a559',
  serviceName: 'serverless-attendance-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.1.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-attendance-app-dev-Auth', timeout: 6 };

try {
  const userHandler = require('./apps/attendance/src/app/lambda/auth/auth0Authorizer.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}