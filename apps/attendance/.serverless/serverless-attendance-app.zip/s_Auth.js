
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'zyskkd',
  applicationName: 'attendance-app',
  appUid: 'zzw25P87wz6GN3t309',
  orgUid: 'bjrHrbt9Twy1n7m82R',
  deploymentUid: '1574d6f4-1483-4a88-8cd2-19c875fe0fa4',
  serviceName: 'serverless-attendance-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.1.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-attendance-app-dev-Auth', timeout: 6 };

try {
  const userHandler = require('./src/app/lambda/auth/auth0Authorizer.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}